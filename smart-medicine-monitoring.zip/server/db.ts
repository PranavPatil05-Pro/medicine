import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertMedicine, InsertUser, medicines, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getMedicinesByUserId(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get medicines: database not available");
    return [];
  }

  try {
    const result = await db
      .select()
      .from(medicines)
      .where(eq(medicines.userId, userId))
      .orderBy(medicines.createdAt);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get medicines:", error);
    throw error;
  }
}

export async function createMedicine(
  userId: number,
  data: Omit<InsertMedicine, "userId" | "createdAt" | "updatedAt">
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db.insert(medicines).values({
      ...data,
      userId,
    });
    return result;
  } catch (error) {
    console.error("[Database] Failed to create medicine:", error);
    throw error;
  }
}

export async function updateMedicine(
  id: number,
  userId: number,
  data: Partial<Omit<InsertMedicine, "userId" | "createdAt" | "updatedAt">>
) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db
      .update(medicines)
      .set(data)
      .where(and(eq(medicines.id, id), eq(medicines.userId, userId)));
    return result;
  } catch (error) {
    console.error("[Database] Failed to update medicine:", error);
    throw error;
  }
}

export async function deleteMedicine(id: number, userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db
      .delete(medicines)
      .where(and(eq(medicines.id, id), eq(medicines.userId, userId)));
    return result;
  } catch (error) {
    console.error("[Database] Failed to delete medicine:", error);
    throw error;
  }
}

export async function getMedicineById(id: number, userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get medicine: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(medicines)
      .where(and(eq(medicines.id, id), eq(medicines.userId, userId)))
      .limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get medicine:", error);
    throw error;
  }
}
