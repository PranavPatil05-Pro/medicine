import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createMedicine,
  deleteMedicine,
  getMedicinesByUserId,
  updateMedicine,
} from "./db";
import {
  checkTemperatureAlert,
  getExpiryStatus,
} from "@shared/types";
import { alertManager } from "./alertManager";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  medicines: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const medicines = await getMedicinesByUserId(ctx.user.id);
      return medicines.map((med) => ({
        ...med,
        expiryStatus: getExpiryStatus(med.expiry),
        temperatureAlert: checkTemperatureAlert(med.currentTemperature) !== null,
      }));
    }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "Medicine name is required"),
          expiry: z.date(),
          temperature: z.string().min(1, "Temperature range is required"),
          currentTemperature: z.number().int().default(20),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await createMedicine(ctx.user.id, {
          name: input.name,
          expiry: input.expiry,
          temperature: input.temperature,
          currentTemperature: input.currentTemperature,
        });
        return result;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          expiry: z.date().optional(),
          temperature: z.string().optional(),
          currentTemperature: z.number().int().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        const result = await updateMedicine(id, ctx.user.id, data);
        return result;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const result = await deleteMedicine(input.id, ctx.user.id);
        return result;
      }),

    getAlerts: protectedProcedure.query(async ({ ctx }) => {
      const medicines = await getMedicinesByUserId(ctx.user.id);
      const alerts = [];

      for (const med of medicines) {
        const expiryStatus = getExpiryStatus(med.expiry);
        const tempAlert = checkTemperatureAlert(med.currentTemperature);

        if (expiryStatus === "expired" && alertManager.shouldShowAlert(med.id, "expired")) {
          alerts.push({
            type: "expired",
            medicineId: med.id,
            medicineName: med.name,
            message: `${med.name} has expired`,
          });
          console.log(`[Alert] Medicine expired: ${med.name}`);
        } else if (expiryStatus === "expiring-soon" && alertManager.shouldShowAlert(med.id, "expiring-soon")) {
          alerts.push({
            type: "expiring-soon",
            medicineId: med.id,
            medicineName: med.name,
            message: `${med.name} is expiring soon`,
          });
          console.log(`[Alert] Medicine expiring soon: ${med.name}`);
        }

        if (tempAlert === "too-hot" && alertManager.shouldShowAlert(med.id, "temperature-alert")) {
          alerts.push({
            type: "temperature-alert",
            medicineId: med.id,
            medicineName: med.name,
            message: `${med.name} temperature is too high (${med.currentTemperature}°C)`,
          });
          console.log(`[Alert] Temperature too high for ${med.name}: ${med.currentTemperature}°C`);
        } else if (tempAlert === "too-cold" && alertManager.shouldShowAlert(med.id, "temperature-alert")) {
          alerts.push({
            type: "temperature-alert",
            medicineId: med.id,
            medicineName: med.name,
            message: `${med.name} temperature is too low (${med.currentTemperature}°C)`,
          });
          console.log(`[Alert] Temperature too low for ${med.name}: ${med.currentTemperature}°C`);
        }
      }

      return alerts;
    }),
  }),
});

export type AppRouter = typeof appRouter;
