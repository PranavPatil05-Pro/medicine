import { describe, expect, it } from "vitest";
import { getExpiryStatus, checkTemperatureAlert } from "@shared/types";

describe("Medicine utility functions", () => {
  describe("getExpiryStatus", () => {
    it("returns 'expired' for dates in the past", () => {
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 1);
      expect(getExpiryStatus(pastDate)).toBe("expired");
    });

    it("returns 'expiring-soon' for dates within 7 days", () => {
      const soonDate = new Date();
      soonDate.setDate(soonDate.getDate() + 3);
      expect(getExpiryStatus(soonDate)).toBe("expiring-soon");
    });

    it("returns 'expiring-soon' for exactly 7 days from now", () => {
      const sevenDaysDate = new Date();
      sevenDaysDate.setDate(sevenDaysDate.getDate() + 7);
      expect(getExpiryStatus(sevenDaysDate)).toBe("expiring-soon");
    });

    it("returns 'safe' for dates more than 7 days away", () => {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      expect(getExpiryStatus(futureDate)).toBe("safe");
    });
  });

  describe("checkTemperatureAlert", () => {
    it("returns 'too-hot' for temperatures above 30°C", () => {
      expect(checkTemperatureAlert(31)).toBe("too-hot");
      expect(checkTemperatureAlert(35)).toBe("too-hot");
      expect(checkTemperatureAlert(50)).toBe("too-hot");
    });

    it("returns 'too-cold' for temperatures below 2°C", () => {
      expect(checkTemperatureAlert(1)).toBe("too-cold");
      expect(checkTemperatureAlert(0)).toBe("too-cold");
      expect(checkTemperatureAlert(-5)).toBe("too-cold");
    });

    it("returns null for temperatures within safe range", () => {
      expect(checkTemperatureAlert(2)).toBeNull();
      expect(checkTemperatureAlert(15)).toBeNull();
      expect(checkTemperatureAlert(25)).toBeNull();
      expect(checkTemperatureAlert(30)).toBeNull();
    });

    it("returns null for boundary temperatures", () => {
      expect(checkTemperatureAlert(2)).toBeNull();
      expect(checkTemperatureAlert(30)).toBeNull();
    });
  });
});
