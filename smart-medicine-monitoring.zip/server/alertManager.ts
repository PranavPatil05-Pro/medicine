/**
 * Alert Manager - Prevents duplicate notifications
 * Tracks alerts by medicineId + alertType with a TTL of 5 minutes
 */

interface AlertKey {
  medicineId: number;
  alertType: "expired" | "expiring-soon" | "temperature-alert";
}

interface CachedAlert {
  timestamp: number;
  ttl: number; // milliseconds
}

class AlertManager {
  private alerts: Map<string, CachedAlert> = new Map();
  private readonly DEFAULT_TTL = 5 * 60 * 1000; // 5 minutes

  private getKey(medicineId: number, alertType: string): string {
    return `${medicineId}:${alertType}`;
  }

  shouldShowAlert(medicineId: number, alertType: "expired" | "expiring-soon" | "temperature-alert"): boolean {
    const key = this.getKey(medicineId, alertType);
    const cached = this.alerts.get(key);

    if (!cached) {
      // First time seeing this alert
      this.alerts.set(key, {
        timestamp: Date.now(),
        ttl: this.DEFAULT_TTL,
      });
      return true;
    }

    const now = Date.now();
    const elapsed = now - cached.timestamp;

    if (elapsed > cached.ttl) {
      // TTL expired, allow alert again
      this.alerts.set(key, {
        timestamp: now,
        ttl: this.DEFAULT_TTL,
      });
      return true;
    }

    // Still within TTL, suppress duplicate
    return false;
  }

  clearAlert(medicineId: number, alertType: string): void {
    const key = this.getKey(medicineId, alertType);
    this.alerts.delete(key);
  }

  clearAllAlerts(): void {
    this.alerts.clear();
  }

  // Clean up expired entries periodically
  cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];
    this.alerts.forEach((cached, key) => {
      if (now - cached.timestamp > cached.ttl) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => this.alerts.delete(key));
  }
}

// Export singleton instance
export const alertManager = new AlertManager();

// Cleanup every minute
setInterval(() => {
  alertManager.cleanup();
}, 60 * 1000);
