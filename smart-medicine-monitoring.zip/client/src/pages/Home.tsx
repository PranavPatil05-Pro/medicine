import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Pill } from "lucide-react";

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated && !loading) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Pill className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Smart Medicine Monitoring</h1>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Manage Your Medicines with Confidence
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Track expiry dates, monitor temperatures, and receive real-time alerts for your medicine inventory. Stay organized and never miss an important update.
          </p>

          <div className="flex gap-4 justify-center mb-16">
            <Button size="lg" onClick={() => window.location.href = getLoginUrl()}>
              Get Started
            </Button>
            <Button size="lg" variant="outline">
              Learn More
            </Button>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl mb-4">📋</div>
            <h3 className="text-lg font-semibold mb-2">Easy Management</h3>
            <p className="text-gray-600">
              Add, edit, and delete medicines with a simple interface. Keep your inventory organized.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl mb-4">🌡️</div>
            <h3 className="text-lg font-semibold mb-2">Temperature Monitoring</h3>
            <p className="text-gray-600">
              Track current temperatures and receive alerts when conditions are outside safe ranges.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-3xl mb-4">⏰</div>
            <h3 className="text-lg font-semibold mb-2">Expiry Tracking</h3>
            <p className="text-gray-600">
              Get notified about expired medicines and items expiring soon. Never use expired medication.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-8 mt-20 text-center">
          <div>
            <div className="text-4xl font-bold text-blue-600">100%</div>
            <p className="text-gray-600 mt-2">Accurate Tracking</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-blue-600">24/7</div>
            <p className="text-gray-600 mt-2">Real-time Alerts</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-blue-600">∞</div>
            <p className="text-gray-600 mt-2">Medicines Supported</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
          <p>&copy; 2026 Smart Medicine Monitoring System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
