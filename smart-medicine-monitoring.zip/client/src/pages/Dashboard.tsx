import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MedicineCard } from "@/components/MedicineCard";
import { MedicineForm } from "@/components/MedicineForm";
import { toast } from "sonner";
import { Plus, Search } from "lucide-react";
import { Medicine } from "@shared/types";
import { TemperatureChart } from "@/components/TemperatureChart";
import { AlertsPanel } from "@/components/AlertsPanel";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | undefined>();

  // Fetch medicines list
  const { data: medicines = [], isLoading, refetch } = trpc.medicines.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Fetch alerts
  const { data: alerts = [] } = trpc.medicines.getAlerts.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Create medicine mutation
  const createMutation = trpc.medicines.create.useMutation({
    onSuccess: () => {
      toast.success("Medicine added successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add medicine");
    },
  });

  // Update medicine mutation
  const updateMutation = trpc.medicines.update.useMutation({
    onSuccess: () => {
      toast.success("Medicine updated successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update medicine");
    },
  });

  // Delete medicine mutation
  const deleteMutation = trpc.medicines.delete.useMutation({
    onSuccess: () => {
      toast.success("Medicine deleted successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete medicine");
    },
  });

  // Show alerts as toasts
  useEffect(() => {
    alerts.forEach((alert) => {
      if (alert.type === "expired") {
        toast.error(alert.message);
      } else if (alert.type === "expiring-soon") {
        toast.warning(alert.message);
      } else if (alert.type === "temperature-alert") {
        toast.error(alert.message);
      }
    });
  }, [alerts]);

  // Auto-refresh medicines every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 10000);

    return () => clearInterval(interval);
  }, [refetch]);

  const handleCreateMedicine = async (data: {
    name: string;
    expiry: Date;
    temperature: string;
    currentTemperature: number;
  }) => {
    await createMutation.mutateAsync(data);
  };

  const handleUpdateMedicine = async (data: {
    name: string;
    expiry: Date;
    temperature: string;
    currentTemperature: number;
  }) => {
    if (!editingMedicine) return;
    await updateMutation.mutateAsync({
      id: editingMedicine.id,
      ...data,
    });
    setEditingMedicine(undefined);
  };

  const handleDeleteMedicine = (id: number) => {
    if (confirm("Are you sure you want to delete this medicine?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEditMedicine = (medicine: Medicine) => {
    setEditingMedicine(medicine);
    setFormOpen(true);
  };

  const handleCloseForm = () => {
    setFormOpen(false);
    setEditingMedicine(undefined);
  };

  // Filter medicines based on search query
  const filteredMedicines = medicines.filter((med) =>
    med.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Smart Medicine Monitoring</h1>
          <p className="text-gray-600">Please log in to continue</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Medicine Inventory</h1>
              <p className="text-gray-600 mt-1">Welcome, {user?.name || "User"}</p>
            </div>
            <Button onClick={() => setFormOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Add Medicine
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Alerts Panel */}
        {alerts.length > 0 && (
          <div className="mb-8">
            <AlertsPanel alerts={alerts} />
          </div>
        )}

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search medicines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Temperature Chart */}
        {medicines.length > 0 && (
          <div className="mb-8">
            <TemperatureChart medicines={medicines} />
          </div>
        )}

        {/* Medicines Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredMedicines.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 mb-4">
              {medicines.length === 0
                ? "No medicines added yet. Start by adding your first medicine."
                : "No medicines match your search."}
            </p>
            {medicines.length === 0 && (
              <Button onClick={() => setFormOpen(true)}>Add First Medicine</Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMedicines.map((medicine) => (
              <MedicineCard
                key={medicine.id}
                medicine={medicine}
                onEdit={handleEditMedicine}
                onDelete={handleDeleteMedicine}
              />
            ))}
          </div>
        )}
      </main>

      {/* Medicine Form Dialog */}
      <MedicineForm
        open={formOpen}
        onOpenChange={handleCloseForm}
        onSubmit={editingMedicine ? handleUpdateMedicine : handleCreateMedicine}
        medicine={editingMedicine}
        isLoading={createMutation.isPending || updateMutation.isPending}
      />
    </div>
  );
}
