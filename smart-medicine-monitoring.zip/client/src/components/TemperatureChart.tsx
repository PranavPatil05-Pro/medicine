import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Medicine } from "@shared/types";

interface TemperatureChartProps {
  medicines: Medicine[];
}

export function TemperatureChart({ medicines }: TemperatureChartProps) {
  // Prepare data for chart - use current temperatures from medicines
  const data = medicines.map((med, index) => ({
    name: med.name.length > 15 ? med.name.substring(0, 15) + "..." : med.name,
    temperature: med.currentTemperature,
    index,
  }));

  if (data.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-6 flex items-center justify-center h-96">
        <p className="text-gray-500">No medicines to display</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold mb-4">Temperature Overview</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis label={{ value: "Temperature (°C)", angle: -90, position: "insideLeft" }} />
          <Tooltip
            formatter={(value) => `${value}°C`}
            labelFormatter={(label) => `Medicine: ${label}`}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="temperature"
            stroke="#3b82f6"
            strokeWidth={2}
            dot={{ fill: "#3b82f6", r: 5 }}
            activeDot={{ r: 7 }}
            name="Current Temperature"
          />
        </LineChart>
      </ResponsiveContainer>

      {/* Temperature Range Reference */}
      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded border border-green-200">
          <p className="text-sm font-medium text-green-900">Safe Range</p>
          <p className="text-lg font-bold text-green-600">2°C - 30°C</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded border border-yellow-200">
          <p className="text-sm font-medium text-yellow-900">Warning</p>
          <p className="text-lg font-bold text-yellow-600">&lt;2°C or &gt;30°C</p>
        </div>
        <div className="bg-red-50 p-4 rounded border border-red-200">
          <p className="text-sm font-medium text-red-900">Alert</p>
          <p className="text-lg font-bold text-red-600">Immediate Action</p>
        </div>
      </div>
    </div>
  );
}
