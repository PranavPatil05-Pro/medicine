import { Medicine } from "@shared/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trash2, Edit2, AlertCircle } from "lucide-react";
import { getExpiryStatus, checkTemperatureAlert, getStatusColor } from "@shared/types";

interface MedicineCardProps {
  medicine: Medicine;
  onEdit: (medicine: Medicine) => void;
  onDelete: (id: number) => void;
}

export function MedicineCard({ medicine, onEdit, onDelete }: MedicineCardProps) {
  const expiryStatus = getExpiryStatus(medicine.expiry);
  const tempAlert = checkTemperatureAlert(medicine.currentTemperature);
  const statusColor = getStatusColor(expiryStatus);

  const daysUntilExpiry = Math.floor(
    (medicine.expiry.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  const expiryText =
    expiryStatus === "expired"
      ? "Expired"
      : expiryStatus === "expiring-soon"
        ? `${daysUntilExpiry} days left`
        : `${daysUntilExpiry} days left`;

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-lg line-clamp-2">{medicine.name}</CardTitle>
          <div className="flex gap-1 flex-shrink-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(medicine)}
              className="h-8 w-8 p-0"
            >
              <Edit2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(medicine.id)}
              className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-3">
        {/* Expiry Status Badge */}
        <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium border ${statusColor}`}>
          {expiryText}
        </div>

        {/* Temperature Range */}
        <div>
          <p className="text-xs text-gray-600 mb-1">Temperature Range</p>
          <p className="text-sm font-medium">{medicine.temperature}°C</p>
        </div>

        {/* Current Temperature */}
        <div>
          <p className="text-xs text-gray-600 mb-1">Current Temperature</p>
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium">{medicine.currentTemperature}°C</p>
            {tempAlert && (
              <div className="flex items-center gap-1 text-red-600">
                <AlertCircle className="h-4 w-4" />
                <span className="text-xs font-medium">
                  {tempAlert === "too-hot" ? "Too Hot" : "Too Cold"}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Expiry Date */}
        <div>
          <p className="text-xs text-gray-600 mb-1">Expiry Date</p>
          <p className="text-sm font-medium">
            {medicine.expiry.toLocaleDateString("en-US", {
              year: "numeric",
              month: "short",
              day: "numeric",
            })}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
