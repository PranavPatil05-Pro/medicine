import { AlertCircle, Clock, Thermometer } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Alert {
  type: "expired" | "expiring-soon" | "temperature-alert";
  medicineId: number;
  medicineName: string;
  message: string;
}

interface AlertsPanelProps {
  alerts: any[];
}

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  if (alerts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-green-600" />
            Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-green-600 font-medium">All clear! No active alerts.</p>
        </CardContent>
      </Card>
    );
  }

  const expiredAlerts = alerts.filter((a) => a.type === "expired");
  const expiringAlerts = alerts.filter((a) => a.type === "expiring-soon");
  const tempAlerts = alerts.filter((a) => a.type === "temperature-alert");

  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-900">
          <AlertCircle className="h-5 w-5 text-red-600" />
          Active Alerts ({alerts.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Expired Medicines */}
        {expiredAlerts.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-red-900 text-sm">Expired Medicines</h4>
            {expiredAlerts.map((alert) => (
              <div
                key={`${alert.medicineId}-expired`}
                className="bg-white border border-red-300 rounded p-3 text-sm"
              >
                <p className="font-medium text-red-900">{alert.medicineName}</p>
                <p className="text-red-700">{alert.message}</p>
              </div>
            ))}
          </div>
        )}

        {/* Expiring Soon */}
        {expiringAlerts.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-yellow-900 text-sm flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Expiring Soon
            </h4>
            {expiringAlerts.map((alert) => (
              <div
                key={`${alert.medicineId}-expiring`}
                className="bg-white border border-yellow-300 rounded p-3 text-sm"
              >
                <p className="font-medium text-yellow-900">{alert.medicineName}</p>
                <p className="text-yellow-700">{alert.message}</p>
              </div>
            ))}
          </div>
        )}

        {/* Temperature Alerts */}
        {tempAlerts.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-orange-900 text-sm flex items-center gap-2">
              <Thermometer className="h-4 w-4" />
              Temperature Alerts
            </h4>
            {tempAlerts.map((alert) => (
              <div
                key={`${alert.medicineId}-temp`}
                className="bg-white border border-orange-300 rounded p-3 text-sm"
              >
                <p className="font-medium text-orange-900">{alert.medicineName}</p>
                <p className="text-orange-700">{alert.message}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
