import { useState, useEffect } from "react";
import { Medicine } from "@shared/types";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface MedicineFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: {
    name: string;
    expiry: Date;
    temperature: string;
    currentTemperature: number;
  }) => Promise<void>;
  medicine?: Medicine;
  isLoading?: boolean;
}

export function MedicineForm({
  open,
  onOpenChange,
  onSubmit,
  medicine,
  isLoading = false,
}: MedicineFormProps) {
  const [formData, setFormData] = useState({
    name: medicine?.name || "",
    expiry: medicine ? medicine.expiry.toISOString().split("T")[0] : "",
    temperature: medicine?.temperature || "",
    currentTemperature: medicine?.currentTemperature || 20,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Sync form data when medicine changes
  useEffect(() => {
    if (open) {
      setFormData({
        name: medicine?.name || "",
        expiry: medicine ? medicine.expiry.toISOString().split("T")[0] : "",
        temperature: medicine?.temperature || "",
        currentTemperature: medicine?.currentTemperature || 20,
      });
      setErrors({});
    }
  }, [medicine, open]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Medicine name is required";
    }

    if (!formData.expiry) {
      newErrors.expiry = "Expiry date is required";
    } else {
      const selectedDate = new Date(formData.expiry);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selectedDate < today) {
        newErrors.expiry = "Expiry date cannot be in the past";
      }
    }

    if (!formData.temperature.trim()) {
      newErrors.temperature = "Temperature range is required";
    }

    if (!Number.isFinite(formData.currentTemperature)) {
      newErrors.currentTemperature = "Current temperature must be a valid number";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error("Please fix the errors in the form");
      return;
    }

    try {
      await onSubmit({
        name: formData.name,
        expiry: new Date(formData.expiry),
        temperature: formData.temperature,
        currentTemperature: formData.currentTemperature,
      });

      setFormData({
        name: "",
        expiry: "",
        temperature: "",
        currentTemperature: 20,
      });
      onOpenChange(false);
    } catch (error) {
      console.error("Form submission error:", error);
      toast.error("Failed to save medicine");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{medicine ? "Edit Medicine" : "Add New Medicine"}</DialogTitle>
          <DialogDescription>
            {medicine
              ? "Update the medicine details"
              : "Add a new medicine to your inventory"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Medicine Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Medicine Name *</Label>
            <Input
              id="name"
              placeholder="e.g., Aspirin"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              disabled={isLoading}
            />
            {errors.name && <p className="text-sm text-red-600">{errors.name}</p>}
          </div>

          {/* Expiry Date */}
          <div className="space-y-2">
            <Label htmlFor="expiry">Expiry Date *</Label>
            <Input
              id="expiry"
              type="date"
              value={formData.expiry}
              onChange={(e) => setFormData({ ...formData, expiry: e.target.value })}
              disabled={isLoading}
            />
            {errors.expiry && <p className="text-sm text-red-600">{errors.expiry}</p>}
          </div>

          {/* Temperature Range */}
          <div className="space-y-2">
            <Label htmlFor="temperature">Temperature Range (e.g., 15-25°C) *</Label>
            <Input
              id="temperature"
              placeholder="e.g., 15-25"
              value={formData.temperature}
              onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
              disabled={isLoading}
            />
            {errors.temperature && (
              <p className="text-sm text-red-600">{errors.temperature}</p>
            )}
          </div>

          {/* Current Temperature */}
          <div className="space-y-2">
            <Label htmlFor="currentTemp">Current Temperature (°C)</Label>
            <Input
              id="currentTemp"
              type="number"
              value={formData.currentTemperature}
              onChange={(e) => {
                const val = parseInt(e.target.value);
                setFormData({ ...formData, currentTemperature: isNaN(val) ? 0 : val });
              }}
              disabled={isLoading}
            />
            {errors.currentTemperature && (
              <p className="text-sm text-red-600">{errors.currentTemperature}</p>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex gap-2 justify-end pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Saving..." : medicine ? "Update" : "Add Medicine"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
