/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

export type ExpiryStatus = "expired" | "expiring-soon" | "safe";

export interface MedicineWithStatus {
  id: number;
  userId: number;
  name: string;
  expiry: Date;
  temperature: string;
  currentTemperature: number;
  createdAt: Date;
  updatedAt: Date;
  expiryStatus: ExpiryStatus;
  temperatureAlert: boolean;
}

export interface TemperatureAlert {
  medicineId: number;
  medicineName: string;
  currentTemperature: number;
  alertType: "too-hot" | "too-cold";
}

export function getExpiryStatus(expiryDate: Date): ExpiryStatus {
  const now = new Date();
  const daysUntilExpiry = Math.floor(
    (expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
  );

  if (daysUntilExpiry < 0) {
    return "expired";
  } else if (daysUntilExpiry <= 7) {
    return "expiring-soon";
  } else {
    return "safe";
  }
}

export function checkTemperatureAlert(
  currentTemp: number
): "too-hot" | "too-cold" | null {
  if (currentTemp > 30) {
    return "too-hot";
  } else if (currentTemp < 2) {
    return "too-cold";
  }
  return null;
}

export function getStatusColor(status: ExpiryStatus): string {
  switch (status) {
    case "expired":
      return "bg-red-100 text-red-800 border-red-300";
    case "expiring-soon":
      return "bg-yellow-100 text-yellow-800 border-yellow-300";
    case "safe":
      return "bg-green-100 text-green-800 border-green-300";
  }
}
